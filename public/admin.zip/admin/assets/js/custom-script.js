$(function() {
  $( "#datepicker" ).datepicker({
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    maxDate: new Date
  });
});

$("#addReportForm").validate({
  rules: {
    title: {
      required: true,
    },
    specimen_type: {
      required: true,
    },
    status: {
      required: true,
    },
    reg_date: {
      required: true,
    },                    
  },
  messages: {
    title: "Please enter report title!",
    specimen_type: "Please choose specimen type!",
    status: "Please choose report status!",
    reg_date: "Please choose registration date!",          
  },
  submitHandler: function(form) {
    var serializedData = new FormData(form);
    var patientId = $('#patientId').val();
    $("#err_mess").html('');
    $('#addReportFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
      headers: {
        'X-CSRF-Token': $('input[name="_token"]').val()
      },
      type: 'post',
      url: _baseURL+'/covid-admin/add-patient-report',
      data: serializedData,
      dataType: 'json',
      processData: false,
      contentType: false,
      cache: false,
      success: function(data) {               
        $('#addReportFormBtn').html('Save Changes');
        if (data.success == true) {
          swal("", data.message, "success", {
            button: "close",
          });
          $('.swal2-confirm').on('click', function(){
            window.location.href = _baseURL+'/covid-admin/patient-report/'+patientId;
          });
        } else {
          swal("", data.message, "error", {
            button: "close",
          });
        }
      }
    });
    return false;
  }
});

$("#updateReportForm").validate({
    rules: {
       title: {
          required: true,
       },
       specimen_type: {
          required: true,
       },
       status: {
          required: true,
       },
       reg_date: {
          required: true,
       },                    
    },
    messages: {
       title: "Please enter report title!",
       specimen_type: "Please choose specimen type!",
       status: "Please choose your status!",
       email: "Please enter your email",
       reg_date: "Please enter registration date!",          
    },
    submitHandler: function(form) {
      var serializedData = new FormData(form);
      var patientId = $('#patientId').val();
       $("#err_mess").html('');
       $('#updateReportFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/update-report',
          data: serializedData,
          dataType: 'json',
          processData: false,
          contentType: false,
          cache: false,
          success: function(data) {               
             $('#updateReportFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/patient-report/'+patientId;
                });
             } else {
                swal("", data.message, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$(document).on('click', '#deleteUser', function(){
	var userId = $(this).data('id');	
	var role = $(this).data('role');
	swal({
	    title: "Are you sure?",
        text: "You will not be able to recover this "+role+"!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
	}).then((result) => {
	    if (result == true) {
	    	deleteUser(userId, role)
	    } else {
	        swal("", "Cancelled!", "error", {
           		button: "close",
        	});
	    }
	});
});

function deleteUser(id, role) {
	$.ajax({
        headers: {
            'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'post',
        url: _baseURL + "/covid-admin/delete-user",
        data: { 
        	id: id,
        	role: role,
        },
        dataType: 'json',
        success: function (data) {
            if (data.success == true) {
            	swal("", data.message, "success", {
               	button: "close",
            });
            $('.swal2-confirm').on('click', function(){
              	location.reload();
            });
         	} else {
            	swal("", data.message, "error", {
               		button: "close",
            	});
         	}
        }
    });
}

$("#updateAdminForm").validate({
    rules: {
       first_name: {
          required: true,
       },        
       dob: {
          required: true,
       },            
       email: {
          required: true,
          email: true
       },
    },
    messages: {
       first_name: "Please enter your first name",
       email: "Please enter your email",
       dob: "Please enter your date of birth",
    },
    submitHandler: function(form) {
      var serializedData = $(form).serialize();
      var role = $('#role').val();
       $("#err_mess").html('');
       $('#updateAdminFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/update-profile',
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             if (data.status == true) {
                $('#edit_personal_details').modal('hide');
                swal("", data.message, "success", {
                   button: "close",
                });
                $('#updateAdminFormBtn').html('Save Changes');
                $('.swal2-confirm').on('click', function(){
                   window.location.reload()
                });
             } else {
                swal("", data.message, "error", {
                   button: "close",
                });
             }


          }
       });
       return false;
    }
});

$("#updateAdminPasswordForm").validate({
    rules: {
       old_password: {
          required: true,
       },
       new_password: {
          required: true,
       },       
       confirm_password: {
        required: true,
        equalTo: '[name="new_password"]',
       }         
    },
    messages: {
       old_password: "Please enter your old password!",
       new_password: "Please enter your new password",
       confirm_password:{
        required: "Please enter your confirm password",
        equalTo: "Password and confirm password must be matched!"
       }
    },
    submitHandler: function(form) {
      var serializedData = $(form).serialize();
      var role = $('#role').val();
       $("#err_mess").html('');
       $('#updateAdminPasswordFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/update-password',
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             if (data.status == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('#updateAdminPasswordFormBtn').html('Save Changes');
                window.location.reload();                
             } else {
                swal("", data.message, "error", {
                   button: "close",
                });
             }


          }
       });
       return false;
    }
});


$("#addHomeForm").validate({
    
    submitHandler: function(form) {
      // var serializedData = $(form).serialize();
      var serializedData = new FormData(form);
       $("#err_mess").html('');
       $('#addHomeFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/home',
          data: serializedData,
          dataType: 'json',
          processData: false,
          contentType: false,
          cache: false,
          success: function(data) {               
             $('#addHomeFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/home/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }


          }
       });
       return false;
    }
});

$("#addAboutForm").validate({
    rules: {
       title: {
          required: true,
       },
       sub_title: {
          required: true,
       }, 
       description: {
          required: true,
       }, 
       description1: {
          required: true,
       },               
    },
    messages: {
       title: "Please enter title!",
       sub_title: "Please enter sub title",      
       description: "Please enter description",      
       description1: "Please enter description",      
    },
    submitHandler: function(form) {
      var serializedData = $(form).serialize();
       $("#err_mess").html('');
       $('#addAboutFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/about-us-data',
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             $('#addAboutFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/about-us/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }


          }
       });
       return false;
    }
});

$("#addContactForm").validate({
    
    submitHandler: function(form) {
      var serializedData = $(form).serialize();
       $("#err_mess").html('');
       $('#addContactFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/contact-us-data',
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             $('#addContactFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/contact-us-page/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$("#addNearestLocationForm").validate({
    rules: {
       title: {
          required: true,
       },
       address: {
          required: true,
       }, 
       working_hour: {
          required: true,
       },   
       mobile_no: {
          required: true,
       },
       location_image: {
          required: true,
       }, 
       link: {
          required: true,
       },                   
    },
    messages: {
       title: "Please enter title!",
       address: "Please enter address!",       
       working_hour: "Please enter working hour!",       
       mobile_no: "Please enter mobile number!",       
       location_image: "Please enter location image!",       
       link: "Please enter link!",       
    },
    submitHandler: function(form) {
      // var serializedData = $(form).serialize();
      var serializedData = new FormData(form);
       $("#err_mess").html('');
       $('#addNearestLocationFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/nearest-location',
          data: serializedData,
          dataType: 'json',
          processData: false,
          contentType: false,
          cache: false,
          success: function(data) {               
             $('#addNearestLocationFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/nearest-location/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$("#addLocationForm").validate({
    
    submitHandler: function(form) {
      var serializedData = new FormData(form);
       $("#err_mess").html('');
       $('#addLocationFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/nearest-location',
          data: serializedData,
          dataType: 'json',
          processData: false,
          contentType: false,
          cache: false,
          success: function(data) {               
             $('#addLocationFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/nearest-location/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$("#updateNearestLocationForm").validate({
    
    submitHandler: function(form) {
      // var serializedData = $(form).serialize();
      var id = $('#locationId').val();
      var serializedData = new FormData(form);
       $("#err_mess").html('');
       $('#updateNearestLocationFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/nearest-location'+'/'+id,
          data: serializedData,
          dataType: 'json',
          processData: false,
          contentType: false,
          cache: false,
          success: function(data) {               
             $('#updateNearestLocationFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/nearest-location';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$(document).on('click', '#deleteLocation', function(){
  var locationId = $(this).data('id');
  swal({
      title: "Are you sure?",
        text: "You will not be able to recover this user!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
  }).then((result) => {
      if (result == true) {
        deleteLocation(locationId)
      } else {
          swal("", "Cancelled!", "error", {
              button: "close",
          });
      }
  });
});

function deleteLocation(id) {
  $.ajax({
        headers: {
            'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'delete',
        url: _baseURL + "/covid-admin/nearest-location"+"/"+id,
        data: { 
          id: id,
        },
        dataType: 'json',
        success: function (data) {
            if (data.success == true) {
              swal("", data.message, "success", {
                button: "close",
            });
            $('.swal2-confirm').on('click', function(){
                location.reload();
            });
          } else {
              swal("", data.message, "error", {
                  button: "close",
              });
          }
        }
    });
}

$("#addFaqForm").validate({
    rules: {
      question: {
        required: true,
      },
      answer: {
        required: true,
      },           
    },
    messages: {
       question: "Please enter your question",
       answer: "Please enter your answer",
    },
    submitHandler: function(form) {
      var serializedData = $(form).serialize();
       $("#err_mess").html('');
       $('#addFaqFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'post',
          url: _baseURL+'/covid-admin/faq',
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             $('#addFaqFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/faq/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$("#updateFaqForm").validate({
    rules: {
      question: {
        required: true,
      },
      answer: {
        required: true,
      },           
    },
    messages: {
       question: "Please enter your question",
       answer: "Please enter your answer",
    },
    submitHandler: function(form) {
      var id = $('#editedFaqId').val();
      var serializedData = $(form).serialize();
       $("#err_mess").html('');
       $('#updateFaqFormBtn').html('Processing <i class="fa fa-spinner fa-spin"></i>');
       $.ajax({
          headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
          },
          type: 'PATCH',
          url: _baseURL+'/covid-admin/faq/'+id,
          data: serializedData,
          dataType: 'json',
          success: function(data) {               
             $('#updateFaqFormBtn').html('Save Changes');
             if (data.success == true) {
                swal("", data.message, "success", {
                   button: "close",
                });
                $('.swal2-confirm').on('click', function(){
                   window.location.href = _baseURL+'/covid-admin/faq/';
                });
             } else {
                swal("", data.errors, "error", {
                   button: "close",
                });
             }
          }
       });
       return false;
    }
});

$(document).on('click', '#deleteFaq', function(){
  var id = $(this).data('id'); 
  swal({
    title: "Are you sure?",
    text: "You will not be able to recover this user!",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result == true) {
      deleteFaq(id);
    } else {
      swal("", "Cancelled!", "error", {
          button: "close",
      });
    }
  });
});

function deleteFaq(id) {
  $.ajax({
        headers: {
            'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'delete',
        url: _baseURL + "/covid-admin/faq"+"/"+id,
        data: { 
          id: id,
        },
        dataType: 'json',
        success: function (data) {
            if (data.success == true) {
              swal("", data.message, "success", {
                button: "close",
            });
            $('.swal2-confirm').on('click', function(){
                location.reload();
            });
          } else {
              swal("", data.message, "error", {
                  button: "close",
              });
          }
        }
    });
}

$(document).on('click', '#deleteSubscriber', function(){
  var id = $(this).data('id'); 
  swal({
    title: "Are you sure?",
    text: "You will not be able to recover this user!",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result == true) {
      deleteSubscriber(id);
    } else {
      swal("", "Cancelled!", "error", {
          button: "close",
      });
    }
  });
});

function deleteSubscriber(id) {
  $.ajax({
    headers: {
        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
    },
    type: 'post',
    url: _baseURL + "/covid-admin/delete-subscriber",
    data: { 
      id: id,
    },
    dataType: 'json',
    success: function (data) {
        if (data.success == true) {
          swal("", data.message, "success", {
            button: "close",
        });
        $('.swal2-confirm').on('click', function(){
            location.reload();
        });
      } else {
          swal("", data.message, "error", {
              button: "close",
          });
      }
    }
  });
}

$(document).on('click', '#deleteReport', function(){
  var id = $(this).data('id');
  swal({
    title: "Are you sure?",
    text: "You will not be able to recover this report!",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result == true) {
      deletePatientReport(id);
    } else {
      swal("", "Cancelled!", "error", {
          button: "close",
      });
    }
  });
});

function deletePatientReport(id) {
  $.ajax({
    headers: {
        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
    },
    type: 'post',
    url: _baseURL + "/covid-admin/delete-report/",
    data: { 
      id: id,
    },
    dataType: 'json',
    success: function (data) {
        if (data.success == true) {
          swal("", data.message, "success", {
            button: "close",
        });
        $('.swal2-confirm').on('click', function(){
            location.reload();
        });
      } else {
          swal("", data.message, "error", {
              button: "close",
          });
      }
    }
  });
}

$(document).on('click', '#userAccountStatus', function(){
  var userId = $(this).data('user-id');
  swal({
    title: "Are you sure?",
    // text: "You will not be able to recover this user!",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, update it!",
  }).then((result) => {
    if (result == true) {
      updateUserAccountStatus(userId);
    } else {
      swal("", "Cancelled!", "error", {
          button: "close",
      });
    }
  });
});

function updateUserAccountStatus(userId) {
  $.ajax({
    headers: {
        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
    },
    type: 'post',
    url: _baseURL + "/covid-admin/account-status/"+ userId,
    data: { 
      userId: userId,
    },
    dataType: 'json',
    success: function (data) {
        if (data.success == true) {
          swal("", data.message, "success", {
            button: "close",
        });
        $('.swal2-confirm').on('click', function(){
            location.reload();
        });
      } else {
          swal("", data.message, "error", {
              button: "close",
          });
      }
    }
  });
}